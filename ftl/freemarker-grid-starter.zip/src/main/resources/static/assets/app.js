
console.log('FreeMarker Grid Starter loaded');
