
package com.example.freemarkergrid.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class HomeController {

    @GetMapping("/")
    public ModelAndView index() {
        return new ModelAndView("pages/home", buildHomeModel(Locale.ENGLISH));
    }

    @GetMapping("/home")
    public ModelAndView home(Locale locale) {
        return new ModelAndView("pages/home", buildHomeModel(locale));
    }

    @GetMapping("/dynamic")
    public ModelAndView dynamic(Locale locale) {
        Map<String, Object> model = new HashMap<>();
        model.putAll(common(locale));

        Map<String, Object> pageLayout = new HashMap<>();
        pageLayout.put("columns", 3);
        pageLayout.put("gap", "16px");
        pageLayout.put("responsive", true);
        model.put("pageLayout", pageLayout);

        // Sample blocks with regions and types
        List<Map<String, Object>> blocks = new ArrayList<>();
        blocks.add(Map.of(
            "type", "card",
            "region", "column-1",
            "order", 10,
            "visible", true,
            "props", Map.of("title", "News", "body", "Latest updates"))
        );
        blocks.add(Map.of(
            "type", "table",
            "region", "column-2",
            "order", 20,
            "visible", true,
            "props", Map.of(
                "columns", List.of(
                    Map.of("key", "name", "label", "Name"),
                    Map.of("key", "status", "label", "Status")
                ),
                "rows", List.of(
                    Map.of("name", "Job A", "status", "Running"),
                    Map.of("name", "Job B", "status", "Pending")
                )
            ))
        );
        blocks.add(Map.of(
            "type", "card",
            "region", "column-3",
            "order", 5,
            "visible", true,
            "props", Map.of("title", "Tips", "body", "Pro tips for teams"))
        );

        // Group by region and sort by order
        Map<String, List<Map<String, Object>>> byRegion = blocks.stream()
            .filter(b -> (Boolean) b.getOrDefault("visible", true))
            .collect(Collectors.groupingBy(
                b -> (String) b.get("region"),
                LinkedHashMap::new,
                Collectors.collectingAndThen(Collectors.toList(), list -> {
                    list.sort(Comparator.comparingInt(b -> (Integer) b.getOrDefault("order", 0)));
                    return list;
                })
            ));
        model.put("blocksByRegion", byRegion);

        return new ModelAndView("pages/dynamic-grid", model);
    }

    private Map<String, Object> buildHomeModel(Locale locale) {
        Map<String, Object> model = new HashMap<>();
        model.putAll(common(locale));

        List<Map<String, Object>> featured = List.of(
            Map.of("name", "Pro Plan", "description", "Best for teams", "price", "₹799/mo"),
            Map.of("name", "Starter", "description", "Beginner friendly", "price", "₹0")
        );
        model.put("featuredProducts", featured);

        Map<String, String> regions = new HashMap<>();
        regions.put("flash", "<div class='alert success'>Welcome back!</div>");
        model.put("regions", regions);
        return model;
    }

    private Map<String, Object> common(Locale locale) {
        Map<String, Object> model = new HashMap<>();
        ResourceBundle rb = ResourceBundle.getBundle("messages", locale);
        Map<String, String> messages = rb.keySet().stream()
            .collect(Collectors.toMap(k -> k, rb::getString));
        model.put("messages", messages);
        model.put("lang", locale.getLanguage());
        model.put("currentYear", Calendar.getInstance().get(Calendar.YEAR));
        return model;
    }
}
