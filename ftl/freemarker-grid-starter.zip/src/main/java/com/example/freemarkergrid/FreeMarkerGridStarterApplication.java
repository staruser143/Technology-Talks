
package com.example.freemarkergrid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreeMarkerGridStarterApplication {
    public static void main(String[] args) {
        SpringApplication.run(FreeMarkerGridStarterApplication.class, args);
    }
}
