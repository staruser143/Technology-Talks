
package com.example.freemarkergrid.config;

import freemarker.cache.ClassTemplateLoader;
import freemarker.cache.MultiTemplateLoader;
import freemarker.cache.StringTemplateLoader;
import freemarker.core.HTMLOutputFormat;
import freemarker.template.Configuration;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration; // alias to avoid name clash

@SpringConfiguration
public class FreemarkerConfig {

    @Bean
    public StringTemplateLoader dbTemplateLoader() {
        return new StringTemplateLoader();
    }

    @Bean
    public Configuration freemarkerConfiguration(StringTemplateLoader dbTemplateLoader) {
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_32);
        cfg.setDefaultEncoding("UTF-8");
        cfg.setIncompatibleImprovements(new Version(2, 3, 24));
        cfg.setOutputFormat(HTMLOutputFormat.INSTANCE);
        cfg.setAutoEscapingPolicy(Configuration.ENABLE_IF_SUPPORTED_AUTO_ESCAPING_POLICY);
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

        ClassTemplateLoader classLoader = new ClassTemplateLoader(getClass(), "/templates");
        MultiTemplateLoader mtl = new MultiTemplateLoader(new freemarker.cache.TemplateLoader[]{
            classLoader, dbTemplateLoader
        });
        cfg.setTemplateLoader(mtl);
        return cfg;
    }
}
