
# FreeMarker Grid Starter

A minimal Spring Boot + FreeMarker project that demonstrates **dynamic N-column layouts** and **data-driven blocks** using macros, regions, and a base layout.

## Requirements
- Java 17+
- Maven 3.8+

## Run
```bash
mvn spring-boot:run
```
Open:
- http://localhost:8080/home — base layout + cards + sidebar
- http://localhost:8080/dynamic — data-driven grid with 3 columns (change in controller to 2 / N)

## Key ideas
- `layouts/base.ftl`: site-wide layout + named regions
- `layouts/grid.ftl`: N-column grid macro that emits `column-1..N` regions
- `layouts/regions.ftl`: region macro renders controller-provided HTML or fallback body
- `components/*.ftl`: reusable component macros (card, table, etc.)
- `pages/dynamic-grid.ftl`: renders blocks grouped by region using component macros
- `FreemarkerConfig`: enables auto-escaping & composes template loaders (classpath + StringTemplateLoader for CMS)

## Customize
- Change column count in `HomeController#dynamic`: `pageLayout.put("columns", 2 or 3 or N)`
- Assign blocks to regions: `region = "column-1"`, `"column-2"`, ...
- Add new components: create a macro file under `templates/components/` and add a `case` in `dynamic-grid.ftl`

## Notes
- Auto-escaping is enabled for HTML rendering; only use `?no_esc` for **trusted, sanitized** HTML in regions.
- For i18n, `messages.properties` is loaded and exposed as a simple map, wrapped by `i18n.ftl` macro.
